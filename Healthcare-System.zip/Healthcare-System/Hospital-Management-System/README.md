# Hospital Management System

A console-based Hospital Management System developed in C++.

## Features

- Patient registration and records
- Doctor management
- Appointment scheduling
- Room management
- Medicine inventory records
- Billing and total calculation
- File-based data storage

## Technologies

- C++
- Object-Oriented Programming
- File Handling
- C++17
- CMake

## How to Run

Compile the project using g++:

g++ -std=c++17 -I include src/main.cpp src/Patient.cpp src/Doctor.cpp src/Appointment.cpp src/Room.cpp src/Medicine.cpp src/Billing.cpp -o hospital.exe

Run:

.\hospital.exe