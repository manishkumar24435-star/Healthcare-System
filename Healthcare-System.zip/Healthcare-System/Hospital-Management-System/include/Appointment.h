#pragma once

class Appointment {
public:
    void add();
    void view();
};