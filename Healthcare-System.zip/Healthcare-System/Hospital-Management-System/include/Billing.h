#pragma once

class Billing {
public:
    void generate();
    void view();
};