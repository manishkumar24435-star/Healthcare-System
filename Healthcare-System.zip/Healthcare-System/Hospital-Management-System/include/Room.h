#pragma once

class Room {
public:
    void add();
    void view();
};