#pragma once

class Doctor {
public:
    void add();
    void view();
};