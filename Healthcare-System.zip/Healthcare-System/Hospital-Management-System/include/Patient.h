#pragma once
#include <string>
using namespace std;

class Patient {
public:
    void add();
    void view();
};