
#ifndef MEDICINE_H
#define MEDICINE_H

class Medicine {
public:
    void add();
    void view();
};

#endif
