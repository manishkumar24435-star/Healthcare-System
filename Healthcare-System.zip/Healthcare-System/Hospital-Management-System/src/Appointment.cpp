#include "Appointment.h"
#include <iostream>
#include <fstream>
using namespace std;

void Appointment::add() {
    string id, patientID, doctorID, date;

    cout << "Appointment ID: ";
    getline(cin, id);
    cout << "Patient ID: ";
    getline(cin, patientID);
    cout << "Doctor ID: ";
    getline(cin, doctorID);
    cout << "Date and time: ";
    getline(cin, date);

    ofstream file("data/appointments.txt", ios::app);
    if (file) {
        file << id << "|" << patientID << "|"
             << doctorID << "|" << date << '\n';
        cout << "Appointment saved!\n";
    } else {
        cout << "Unable to open appointment file.\n";
    }
}

void Appointment::view() {
    ifstream file("data/appointments.txt");
    string line;
    cout << "\n--- Appointments ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No appointments found.\n";
}