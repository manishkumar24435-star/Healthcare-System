#include "Doctor.h"
#include <iostream>
#include <fstream>
using namespace std;

void Doctor::add() {
    string id, name, specialization, phone;

    cout << "Doctor ID: ";
    getline(cin, id);
    cout << "Doctor Name: ";
    getline(cin, name);
    cout << "Specialization: ";
    getline(cin, specialization);
    cout << "Phone: ";
    getline(cin, phone);

    ofstream file("data/doctors.txt", ios::app);
    if (file) {
        file << id << "|" << name << "|"
             << specialization << "|" << phone << '\n';
        cout << "Doctor added successfully!\n";
    } else {
        cout << "Unable to open doctor file.\n";
    }
}

void Doctor::view() {
    ifstream file("data/doctors.txt");
    string line;
    cout << "\n--- Doctor Records ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No doctors found.\n";
}