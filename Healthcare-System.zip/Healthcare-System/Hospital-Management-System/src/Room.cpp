#include "Room.h"
#include <iostream>
#include <fstream>
using namespace std;

void Room::add() {
    string id, type, status;

    cout << "Room Number: ";
    getline(cin, id);
    cout << "Room Type: ";
    getline(cin, type);
    cout << "Status (Available/Occupied): ";
    getline(cin, status);

    ofstream file("data/rooms.txt", ios::app);
    if (file) {
        file << id << "|" << type << "|"
             << status << '\n';
        cout << "Room saved successfully!\n";
    } else {
        cout << "Unable to open room file.\n";
    }
}

void Room::view() {
    ifstream file("data/rooms.txt");
    string line;
    cout << "\n--- Room Records ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No rooms found.\n";
}