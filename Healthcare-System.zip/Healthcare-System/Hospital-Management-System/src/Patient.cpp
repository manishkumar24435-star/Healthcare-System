#include "Patient.h"
#include <iostream>
#include <fstream>
using namespace std;

void Patient::add() {
    string id, name, age, gender, phone;

    cout << "Patient ID: ";
    getline(cin, id);
    cout << "Name: ";
    getline(cin, name);
    cout << "Age: ";
    getline(cin, age);
    cout << "Gender: ";
    getline(cin, gender);
    cout << "Phone: ";
    getline(cin, phone);

    ofstream file("data/patients.txt", ios::app);
    if (file) {
        file << id << "|" << name << "|" << age
             << "|" << gender << "|" << phone << '\n';
        cout << "Patient added successfully!\n";
    } else {
        cout << "Unable to open patient file.\n";
    }
}

void Patient::view() {
    ifstream file("data/patients.txt");
    string line;

    cout << "\n--- Patient Records ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No patients found.\n";
}