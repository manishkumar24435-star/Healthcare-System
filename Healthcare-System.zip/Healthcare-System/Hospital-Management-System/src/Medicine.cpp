#include "Medicine.h"
#include <iostream>
#include <fstream>
using namespace std;

void Medicine::add() {
    string id, name, quantity, price;

    cout << "Medicine ID: ";
    getline(cin, id);
    cout << "Medicine Name: ";
    getline(cin, name);
    cout << "Quantity: ";
    getline(cin, quantity);
    cout << "Price per unit: ";
    getline(cin, price);

    ofstream file("data/medicines.txt", ios::app);
    if (file) {
        file << id << "|" << name << "|"
             << quantity << "|" << price << '\n';
        cout << "Medicine saved successfully!\n";
    } else {
        cout << "Unable to open medicine file.\n";
    }
}

void Medicine::view() {
    ifstream file("data/medicines.txt");
    string line;
    cout << "\n--- Medicine Records ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No medicines found.\n";
}