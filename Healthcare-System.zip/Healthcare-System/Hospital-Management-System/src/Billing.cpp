#include "Billing.h"
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void Billing::generate() {
    string billID, patientID;
    double consultation, room, medicine;

    cout << "Bill ID: ";
    getline(cin, billID);
    cout << "Patient ID: ";
    getline(cin, patientID);

    cout << "Consultation Fee: ";
    if (!(cin >> consultation) || consultation < 0) {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid amount.\n";
        return;
    }

    cout << "Room Charges: ";
    if (!(cin >> room) || room < 0) {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid amount.\n";
        return;
    }

    cout << "Medicine Charges: ";
    if (!(cin >> medicine) || medicine < 0) {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid amount.\n";
        return;
    }

    cin.ignore(10000, '\n');

    double total = consultation + room + medicine;

    ofstream file("data/bills.txt", ios::app);
    if (!file) {
        cout << "Unable to save bill.\n";
        return;
    }

    file << billID << "|" << patientID << "|"
         << fixed << setprecision(2)
         << consultation << "|" << room << "|"
         << medicine << "|" << total << '\n';

    cout << fixed << setprecision(2)
         << "Total Bill: Rs. " << total << '\n';
    cout << "Bill saved successfully!\n";
}

void Billing::view() {
    ifstream file("data/bills.txt");
    string line;
    cout << "\n--- Billing Records ---\n";
    bool found = false;

    while (getline(file, line)) {
        for (char &c : line)
            if (c == '|') c = ' ';
        cout << line << '\n';
        found = true;
    }

    if (!found) cout << "No bills found.\n";
}