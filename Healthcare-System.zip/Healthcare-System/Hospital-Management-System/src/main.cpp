
#include <iostream>
#include <fstream>
#include <string>
#include <limits>
#include "Patient.h"
#include "Doctor.h"
#include "Appointment.h"
#include "Room.h"
#include "Medicine.h"
#include "Billing.h"

using namespace std;

int main() {
    // Ensure the data folder exists before running.
    // Create the data folder manually in the project root if needed.

    Patient patient;
    Doctor doctor;
    Appointment appointment;
    Room room;
    Medicine medicine;
    Billing billing;

    int choice = -1;

    do {
        cout << "\n====================================\n";
        cout << "     HOSPITAL MANAGEMENT SYSTEM\n";
        cout << "====================================\n";
        cout << "1. Add Patient\n";
        cout << "2. View Patients\n";
        cout << "3. Add Doctor\n";
        cout << "4. View Doctors\n";
        cout << "5. Add Appointment\n";
        cout << "6. View Appointments\n";
        cout << "7. Add Room\n";
        cout << "8. View Rooms\n";
        cout << "9. Add Medicine\n";
        cout << "10. View Medicines\n";
        cout << "11. Generate Bill\n";
        cout << "12. View Bills\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";

        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid number.\n";
            choice = -1;
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1:
                patient.add();
                break;
            case 2:
                patient.view();
                break;
            case 3:
                doctor.add();
                break;
            case 4:
                doctor.view();
                break;
            case 5:
                appointment.add();
                break;
            case 6:
                appointment.view();
                break;
            case 7:
                room.add();
                break;
            case 8:
                room.view();
                break;
            case 9:
                medicine.add();
                break;
            case 10:
                medicine.view();
                break;
            case 11:
                billing.generate();
                break;
            case 12:
                billing.view();
                break;
            case 0:
                cout << "Thank you for using the system!\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 0);

    return 0;
}
